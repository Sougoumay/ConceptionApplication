package modele;

public class CoupInvalideException extends Exception{
    public CoupInvalideException(String message) {
        super(message);
    }
}
