package modele;

public class NimIA {
    public void StrategieN(){}
}
