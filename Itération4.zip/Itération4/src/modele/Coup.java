package modele;

public class Coup {

}
