package modele;

public class PuisssanceIA {
    public void strategieP(){}
}
