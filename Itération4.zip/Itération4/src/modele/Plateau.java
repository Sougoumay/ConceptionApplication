package modele;

public class Plateau {


    public void gererCoup(Coup coup) throws CoupInvalideException {}

}
